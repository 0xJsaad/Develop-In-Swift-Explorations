//
//  GameState.swift
//  RPS
//
//  Created by Matthew Hanlon on 05/03/2021.
//  Created by 0xJs on 10/3/23.
//
//

import Foundation

enum GameState {
    case start
    case win
    case lose
    case draw
}
