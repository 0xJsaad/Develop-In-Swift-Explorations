//
//  AppDelegate.swift
//  Meme Maker
//
//  Created by 0xJs on 10/3/23.
//

import Foundation

struct CaptionChoice{
    var emoji : String;
    var caption : String;
    var imageName : String;
}
